"app > src > main"

1. "activity_main.xml" -- file is in "res > layout"

2. "MainActivity.java" -- file is in "java > com > example > corona"